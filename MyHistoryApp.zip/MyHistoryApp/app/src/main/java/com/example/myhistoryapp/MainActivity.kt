package com.example.myhistoryapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var btnEnter: Button
    private lateinit var inputAge: EditText
    private lateinit var tvFigure: TextView
    private lateinit var tvDeath: TextView

    private var historicalFigures = listOf(
        HistoricalFigures("Diana, Pricess of Wales", 36),
        HistoricalFigures("Stephen Hawking", 76),
        HistoricalFigures("Winnie Mandela", 81),
        HistoricalFigures("Frene Ginwala",90),
        HistoricalFigures("Aziz Pahad",54),
        HistoricalFigures("Albertina Sisulu",92),
        HistoricalFigures("Steve Biko",30),
        HistoricalFigures("Walteer Sisulu",90),
        HistoricalFigures("Mahatma Gandhi",78),
        HistoricalFigures("Martin Luther King",39)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       btnEnter = findViewById(R.id.btnEnter)
        inputAge = findViewById(R.id.inputAge)
        tvFigure = findViewById(R.id.tvFigure)
        tvDeath = findViewById(R.id.tvDeath)

        btnEnter.setOnClickListener {
            val enteredAge = inputAge.text.toString().toIntOrNull()


            if (enteredAge != null) {
                val matchingFigure = historicalFigures.find { it.age == enteredAge }
                if (matchingFigure != null) {
                    tvFigure.text = matchingFigure.name
                    tvDeath.text = "(${matchingFigure.age})"
                } else {
                    tvFigure.text = "No historical figure matches this age in the list."
                    tvDeath.text = " $enteredAge"
                }
            } else {
                tvFigure.text = ""
                tvDeath.text = "Please enter name, surname and age"
            }
        }
    }
    private data class HistoricalFigures(val name: String, val age: Int)
}